public class Autor {
	public int Id { get; set; }
	public string nome { get; set; }
	public string testes { get; set; }
	public List<Livro> livros { get; set; }
}
