public class Curso {
	public int Id { get; set; }
	public string nome { get; set; }
	public List<Estudante> estudantes { get; set; }
	public int turma { get; set; }
	public double notas { get; set; }
	public char tchar { get; set; }
	public bool booleano { get; set; }
}
