public class Estudante {
	public int Id { get; set; }
	public string nome { get; set; }
	public int idade { get; set; }
	public Curso curso { get; set; }
}
