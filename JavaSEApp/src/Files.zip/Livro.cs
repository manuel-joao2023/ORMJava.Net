public class Livro {
	public int Id { get; set; }
	public string titulo { get; set; }
	public Autor autor { get; set; }
}
